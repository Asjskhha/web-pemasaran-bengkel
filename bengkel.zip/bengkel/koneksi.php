<?php
$host = 'localhost';       // Host database
$dbname = 'db_bengkel';  // Nama database Anda
$username = 'root';         // Username database (default: root)
$password = '';             // Password database (default: kosong untuk XAMPP)

try {
    // Inisialisasi PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Koneksi database gagal: " . $e->getMessage();
}
?>
