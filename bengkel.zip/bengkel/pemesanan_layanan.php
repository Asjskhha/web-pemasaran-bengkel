<?php
// Koneksi ke database
$servername = "localhost";
$username = "root"; // Ganti dengan username Anda
$password = ""; // Ganti dengan password Anda
$dbname = "db_bengkel"; // Ganti dengan nama database Anda

$conn = new mysqli($servername, $username, $password, $dbname);

// Mengecek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Proses ketika formulir dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $serviceId = $_POST['service_id'];
    $tanggalWaktu = $_POST['tanggal_waktu'];

    // Mendapatkan user_id dari session (pastikan ini telah di-set sebelumnya)
    $userId = $_SESSION['user_id'];

    // Menyimpan pemesanan layanan ke database
    $sql = "INSERT INTO janji_temu (user_id, service_id, tanggal_waktu, status) VALUES (?, ?, ?, 'pending')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iis", $userId, $serviceId, $tanggalWaktu);

    if ($stmt->execute()) {
        $message = "Pemasanan layanan berhasil dibuat.";
    } else {
        $message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Mengambil data layanan untuk ditampilkan
$sql = "SELECT service_id, nama_service, deskripsi_service, price FROM service";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pemesanan Layanan</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .container {
            margin-top: 20px;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Pemesanan Layanan</h2>

    <?php if (isset($message)): ?>
        <div class="alert alert-success" role="alert">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="form-group">
            <label for="service_id">Layanan:</label>
            <select class="form-control" id="service_id" name="service_id" required>
                <option value="">Pilih Layanan</option>
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <option value="<?php echo $row['service_id']; ?>"><?php echo $row['nama_service'] . " - Rp " . $row['price']; ?></option>
                    <?php endwhile; ?>
                <?php endif; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="tanggal_waktu">Tanggal dan Waktu:</label>
            <input type="datetime-local" class="form-control" id="tanggal_waktu" name="tanggal_waktu" required>
        </div>
        <button type="submit" class="btn btn-primary">Pesan Layanan</button>
    </form>
</div>
<script src="script.js"></script>
</body>
</html>

<?php
$conn->close();
?>
