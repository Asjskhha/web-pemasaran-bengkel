<?php
// Menghubungkan ke database
include 'koneksi.php';

// Menangani aksi tambah layanan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_layanan'])) {
    // Mendapatkan data dari form
    $nama_service = $_POST['nama_service'];
    $deskripsi_service = $_POST['deskripsi_service'];
    $price = $_POST['price'];
    $durasi = $_POST['durasi'];
    $status = $_POST['status'];
    $tanggal_berakhir = $_POST['tanggal_berakhir'] ? $_POST['tanggal_berakhir'] : NULL;

    // Query untuk memasukkan data layanan ke dalam database
    $query = "INSERT INTO layanan (nama_service, deskripsi_service, price, durasi, status, tanggal_berakhir)
              VALUES (:nama_service, :deskripsi_service, :price, :durasi, :status, :tanggal_berakhir)";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':nama_service', $nama_service);
    $stmt->bindParam(':deskripsi_service', $deskripsi_service);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':durasi', $durasi);
    $stmt->bindParam(':status', $status);
    $stmt->bindParam(':tanggal_berakhir', $tanggal_berakhir);
    $stmt->execute();
}

// Menangani aksi edit layanan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_layanan'])) {
    $service_id = $_POST['service_id'];
    $nama_service = $_POST['nama_service'];
    $deskripsi_service = $_POST['deskripsi_service'];
    $price = $_POST['price'];
    $durasi = $_POST['durasi'];
    $status = $_POST['status'];
    $tanggal_berakhir = $_POST['tanggal_berakhir'] ? $_POST['tanggal_berakhir'] : NULL;

    // Query untuk memperbarui data layanan
    $query = "UPDATE layanan SET 
              nama_service = :nama_service, 
              deskripsi_service = :deskripsi_service, 
              price = :price, 
              durasi = :durasi, 
              status = :status, 
              tanggal_berakhir = :tanggal_berakhir
              WHERE service_id = :service_id";
    
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':service_id', $service_id);
    $stmt->bindParam(':nama_service', $nama_service);
    $stmt->bindParam(':deskripsi_service', $deskripsi_service);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':durasi', $durasi);
    $stmt->bindParam(':status', $status);
    $stmt->bindParam(':tanggal_berakhir', $tanggal_berakhir);
    $stmt->execute();
}

// Menangani aksi hapus layanan
if (isset($_GET['hapus_layanan'])) {
    $service_id = $_GET['hapus_layanan'];
    $query = "DELETE FROM layanan WHERE service_id = :service_id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':service_id', $service_id);
    $stmt->execute();
}

// Query untuk mengambil data layanan dari database
$queryLayanan = "SELECT service_id, nama_service, deskripsi_service, price, durasi, status, tanggal_berakhir 
                 FROM layanan";
$stmtLayanan = $pdo->prepare($queryLayanan);
$stmtLayanan->execute();
$layananData = $stmtLayanan->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Layanan Admin</title>
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Gaya umum untuk tabel */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    font-size: 16px;
    text-align: left;
}

table th, table td {
    padding: 12px 15px;
    border: 1px solid #ddd;
}

table th {
    background-color: #f4f4f4;
    font-weight: bold;
}

table tbody tr:nth-child(even) {
    background-color: #f9f9f9;
}

table tbody tr:hover {
    background-color: #f1f1f1;
}

/* Gaya untuk tombol */
.button {
    padding: 8px 15px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.button:hover {
    background-color: #45a049;
}

.button-danger {
    background-color: #f44336;
}

.button-danger:hover {
    background-color: #e53935;
}

/* Gaya untuk tombol edit dan hapus dengan "x" */
.button-edit, .button-delete {
    padding: 5px 10px;
    font-size: 18px;
    background-color: transparent;
    border: none;
    cursor: pointer;
    color: #555;
}

.button-edit {
    color: #4CAF50;
}

.button-edit:hover {
    background-color: #e8f5e9;
}

.button-delete {
    color: #f44336;
}

.button-delete:hover {
    background-color: #ffebee;
}

/* Gaya untuk form modal */
form {
    display: flex;
    flex-direction: column;
    gap: 15px;
    padding: 20px;
}

form label {
    font-size: 14px;
    font-weight: bold;
}

form input, form textarea, form select {
    padding: 8px;
    font-size: 16px;
    border-radius: 4px;
    border: 1px solid #ccc;
    width: 100%;
    box-sizing: border-box;
}

form input[type="date"] {
    width: 200px;
}

form button[type="submit"] {
    padding: 10px 20px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

form button[type="submit"]:hover {
    background-color: #45a049;
}

/* Gaya modal */
#tambahLayananModal, #editLayananModal {
    display: none;
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    padding-top: 50px;
    z-index: 1000;
}

#tambahLayananModal > div, #editLayananModal > div {
    background-color: white;
    padding: 20px;
    margin: 0 auto;
    width: 50%;
    border-radius: 8px;
}

#tambahLayananModal span, #editLayananModal span {
    cursor: pointer;
    color: red;
    position: absolute;
    top: 15px;
    right: 15px;
    font-size: 18px;
}

/* Gaya untuk status */
.status {
    text-transform: capitalize;
}

.status.aktif {
    color: green;
}

.status.tidak-aktif {
    color: red;
}

/* Responsif untuk tampilan mobile */
@media (max-width: 768px) {
    table {
        font-size: 14px;
    }

    table th, table td {
        padding: 8px 10px;
    }

    #tambahLayananModal > div, #editLayananModal > div {
        width: 80%;
    }
}

    </style>
</head>
<body>
   <!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-smile'></i>
			<span class="text">Admin</span>
		</a>
		<ul class="side-menu top">
        <li>
				<a href="dashboard.php">
					<i class='bx bxs-shopping-bag-alt'></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="manajemen_pengguna.php">
					<i class='bx bxs-shopping-bag-alt'></i>
					<span class="text">Manajemen Pengguna</span>
				</a>
			</li>
			<li>
				<a href="manajemen_kampanye.php">
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">Manajemen Kampanye</span>
				</a>
			</li>
			<li>
				<a href="inventaris.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Investaris</span>
				</a>
			</li>
			<li>
				<a href="janjitemu_admin.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Janji Temu</span>
				</a>
			</li>
			<li>
				<a href="layanan_admin.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Layanan</span>
				</a>
			</li>
			<li>
				<a href="laporan.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Laporan Kinerja</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="settings.php">
					<i class='bx bxs-cog' ></i>
					<span class="text">Settings</span>
				</a>
			</li>
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="logout.php">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->

    <!-- CONTENT -->
    <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
        </nav>

        <main>
    <h2>Daftar Layanan (Admin)</h2>

    <button onclick="document.getElementById('tambahLayananModal').style.display='block'" class="button">Tambah Layanan</button>

    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Layanan</th>
                <th>Deskripsi Layanan</th>
                <th>Harga</th>
                <th>Durasi</th>
                <th>Status</th>
                <th>Tanggal Berakhir</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($layananData) > 0): ?>
                <?php foreach ($layananData as $index => $layanan): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td><?php echo htmlspecialchars($layanan['nama_service']); ?></td>
                        <td><?php echo htmlspecialchars($layanan['deskripsi_service']); ?></td>
                        <td><?php echo 'Rp ' . number_format($layanan['price'], 0, ',', '.'); ?></td>
                        <td><?php echo htmlspecialchars($layanan['durasi']); ?> menit</td>
                        <td class="status"><?php echo htmlspecialchars($layanan['status']); ?></td>
                        <td><?php echo htmlspecialchars($layanan['tanggal_berakhir'] ?? 'Tidak Terbatas'); ?></td>
                        <td>
                            <button onclick="editLayanan(<?php echo htmlspecialchars(json_encode($layanan)); ?>)" class="button">Edit</button>
                            <a href="?hapus_layanan=<?php echo $layanan['service_id']; ?>" class="button button-danger">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8">Tidak ada layanan tersedia.</td>
                </tr>
            <?php endif; ?>
            </main>
        </tbody>
    </table>

 
    <!-- Modal untuk tambah layanan -->
    <div id="tambahLayananModal" style="display:none; position: fixed; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); padding-top: 50px;">
        <div style="background-color: white; padding: 20px; margin: 0 auto; width: 50%; border-radius: 8px;">
            <span onclick="document.getElementById('tambahLayananModal').style.display='none'" style="cursor: pointer; color: red;">&times;</span>
            <h2>Tambah Layanan Baru</h2>

            <form method="POST" action="">
                <label for="nama_service">Nama Layanan:</label>
                <input type="text" id="nama_service" name="nama_service" required><br><br>

                <label for="deskripsi_service">Deskripsi Layanan:</label>
                <textarea id="deskripsi_service" name="deskripsi_service"></textarea><br><br>

                <label for="price">Harga:</label>
                <input type="number" id="price" name="price" required><br><br>

                <label for="durasi">Durasi (Menit):</label>
                <input type="number" id="durasi" name="durasi" required><br><br>

                <label for="status">Status:</label>
                <select name="status" id="status">
                    <option value="Aktif">Aktif</option>
                    <option value="Tidak Aktif">Tidak Aktif</option>
                </select><br><br>

                <label for="tanggal_berakhir">Tanggal Berakhir:</label>
                <input type="date" id="tanggal_berakhir" name="tanggal_berakhir"><br><br>

                <button type="submit" name="tambah_layanan">Tambah Layanan</button>
            </form>
        </div>
    </div>

    <!-- Modal untuk edit layanan -->
    <div id="editLayananModal" style="display:none; position: fixed; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); padding-top: 50px;">
        <div style="background-color: white; padding: 20px; margin: 0 auto; width: 50%; border-radius: 8px;">
            <span onclick="document.getElementById('editLayananModal').style.display='none'" style="cursor: pointer; color: red;">&times;</span>
            <h2>Edit Layanan</h2>

            <form method="POST" action="">
                <input type="hidden" id="edit_service_id" name="service_id">
                <label for="edit_nama_service">Nama Layanan:</label>
                <input type="text" id="edit_nama_service" name="nama_service" required><br><br>

                <label for="edit_deskripsi_service">Deskripsi Layanan:</label>
                <textarea id="edit_deskripsi_service" name="deskripsi_service"></textarea><br><br>

                <label for="edit_price">Harga:</label>
                <input type="number" id="edit_price" name="price" required><br><br>

                <label for="edit_durasi">Durasi (Menit):</label>
                <input type="number" id="edit_durasi" name="durasi" required><br><br>

                <label for="edit_status">Status:</label>
                <select name="status" id="edit_status">
                    <option value="Aktif">Aktif</option>
                    <option value="Tidak Aktif">Tidak Aktif</option>
                </select><br><br>

                <label for="edit_tanggal_berakhir">Tanggal Berakhir:</label>
                <input type="date" id="edit_tanggal_berakhir" name="tanggal_berakhir"><br><br>

                <button type="submit" name="edit_layanan">Simpan Perubahan</button>
            </form>
        </div>
    </div>

    <script>
        function editLayanan(layanan) {
            document.getElementById('edit_service_id').value = layanan.service_id;
            document.getElementById('edit_nama_service').value = layanan.nama_service;
            document.getElementById('edit_deskripsi_service').value = layanan.deskripsi_service;
            document.getElementById('edit_price').value = layanan.price;
            document.getElementById('edit_durasi').value = layanan.durasi;
            document.getElementById('edit_status').value = layanan.status;
            document.getElementById('edit_tanggal_berakhir').value = layanan.tanggal_berakhir;
            document.getElementById('editLayananModal').style.display = 'block';
        }
    </script>
</body>
</html>
