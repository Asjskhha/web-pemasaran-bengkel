<?php
// Koneksi ke database
$servername = "localhost";
$username = "root"; // Ganti dengan username Anda
$password = ""; // Ganti dengan password Anda
$dbname = "db_bengkel"; // Ganti dengan nama database Anda

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Memperbarui data janji temu
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['updateId'])) {
        // Memperbarui data
        $id = $_POST['updateId'];
        $status = $_POST['status'];
        $alasanPenolakan = $_POST['alasanPenolakan'];

        // Update data janji temu
        $sql = "UPDATE janji_temu SET status=?, alasan_penolakan=? WHERE janjitemu_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $status, $alasanPenolakan, $id);

        if ($stmt->execute()) {
            $message = "Janji temu berhasil diperbarui.";
        } else {
            $message = "Error: " . $stmt->error;
        }

        $stmt->close();
    } elseif (isset($_POST['deleteId'])) {
        // Menghapus data
        $id = $_POST['deleteId'];

        // Hapus data janji temu
        $sql = "DELETE FROM janji_temu WHERE janjitemu_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $message = "Janji temu berhasil dihapus.";
        } else {
            $message = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

// Mengambil data janji temu dengan informasi nama_service dari tabel layanan
$sql = "SELECT jt.janjitemu_id, jt.service_id, jt.tanggal_waktu, jt.status, jt.alasan_penolakan, l.nama_service
        FROM janji_temu jt
        LEFT JOIN layanan l ON jt.service_id = l.service_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Janji Temu Admin</title>
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
     <!-- Bootstrap CSS -->
     <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<style>
       /* Gaya umum untuk tabel */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    font-size: 16px;
    text-align: left;
    background-color: #fefefe;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    overflow: hidden;
}

table th, table td {
    padding: 15px;
    border-bottom: 1px solid #ddd;
}

table th {
    background-color: #4CAF50;
    color: white;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
}

table tbody tr:nth-child(even) {
    background-color: #f9f9f9;
}

table tbody tr:hover {
    background-color: #f1f1f1;
}

table td {
    font-size: 14px;
}

/* Gaya untuk aksi tombol di tabel */
.table-actions {
    display: flex;
    gap: 8px;
}

.table-actions button {
    padding: 6px 12px;
    font-size: 14px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.table-actions .edit {
    background-color: #4CAF50;
    color: white;
}

.table-actions .edit:hover {
    background-color: #45a049;
}

.table-actions .delete {
    background-color: #f44336;
    color: white;
}

.table-actions .delete:hover {
    background-color: #e53935;
}

/* Responsif untuk tampilan mobile */
@media (max-width: 768px) {
    table {
        font-size: 14px;
    }

    table th, table td {
        padding: 10px;
    }
}

    </style>
   <!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-smile'></i>
			<span class="text">Admin</span>
		</a>
		<ul class="side-menu top">
        <li>
				<a href="dashboard.php">
					<i class='bx bxs-shopping-bag-alt'></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="manajemen_pengguna.php">
					<i class='bx bxs-shopping-bag-alt'></i>
					<span class="text">Manajemen Pengguna</span>
				</a>
			</li>
			<li>
				<a href="manajemen_kampanye.php">
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">Manajemen Kampanye</span>
				</a>
			</li>
			<li>
				<a href="inventaris.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Investaris</span>
				</a>
			</li>
			<li>
				<a href="janjitemu_admin.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Janji Temu</span>
				</a>
			</li>
			<li>
				<a href="layanan_admin.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Layanan</span>
				</a>
			</li>
			<li>
				<a href="laporan.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Laporan Kinerja</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="settings.php">
					<i class='bx bxs-cog' ></i>
					<span class="text">Settings</span>
				</a>
			</li>
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="logout.php">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->

    <!-- CONTENT -->
    <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="notifikasi.php" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a>
        </nav>

     <main>
<div class="container">
    <h2>Daftar Janji Temu</h2>
    
    <?php if (isset($message)): ?>
        <div class="alert alert-success" role="alert">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID Janji Temu</th>
                <th>Nama Layanan</th> <!-- Menampilkan nama layanan -->
                <th>Tanggal & Waktu</th>
                <th>Status</th>
                <th>Alasan Penolakan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['janjitemu_id']; ?></td>
                        <td><?php echo $row['nama_service']; ?></td> <!-- Menampilkan nama layanan -->
                        <td><?php echo $row['tanggal_waktu']; ?></td>
                        <td><?php echo ucfirst($row['status']); ?></td>
                        <td><?php echo $row['alasan_penolakan'] ? $row['alasan_penolakan'] : '-'; ?></td>
                        <td>
                            <button class="btn btn-primary" onclick="showUpdateForm(<?php echo $row['janjitemu_id']; ?>, '<?php echo $row['status']; ?>', '<?php echo addslashes($row['alasan_penolakan']); ?>')">Perbarui</button>
                            <!-- Tombol Hapus -->
                            <form method="POST" action="" style="display:inline;">
                                <input type="hidden" name="deleteId" value="<?php echo $row['janjitemu_id']; ?>">
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus janji temu ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">Tidak ada janji temu.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div id="updateForm" style="display:none; margin-top: 20px;">
        <h3>Form Perbarui Janji Temu</h3>
        <form id="formUpdate" method="POST" action="">
            <input type="hidden" id="updateId" name="updateId">
            <div class="form-group">
                <label for="status">Status:</label>
                <select class="form-control" id="status" name="status">
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                </select>
            </div>
            <div class="form-group">
                <label for="alasanPenolakan">Alasan Penolakan:</label>
                <input type="text" class="form-control" id="alasanPenolakan" name="alasanPenolakan">
            </div>
            <button type="submit" class="btn btn-success">Simpan Perubahan</button>
            <button type="button" class="btn btn-secondary" onclick="hideUpdateForm()">Batal</button>
        </form>
        </main>   
    </div>
</div>

<script>
    function showUpdateForm(id, status, alasan) {
        document.getElementById("updateId").value = id;
        document.getElementById("status").value = status;
        document.getElementById("alasanPenolakan").value = alasan;
        document.getElementById("updateForm").style.display = "block";
    }

    function hideUpdateForm() {
        document.getElementById("updateForm").style.display = "none";
    }
</script> 
<script src="script.js"></script>
</body>
</html>

<?php
$conn->close();
?>
