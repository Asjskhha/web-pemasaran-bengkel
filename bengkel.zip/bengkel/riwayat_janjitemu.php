<?php
// Menghubungkan ke database
include 'koneksi.php';  // Pastikan jalur ini sesuai dengan lokasi file koneksi Anda

// Mendapatkan data riwayat janji temu untuk pengguna yang sedang login
$user_id = 1; // Gantilah dengan ID pengguna yang sesuai, misalnya menggunakan session untuk mendapatkan user_id yang tepat

// Proses hapus jika tombol hapus ditekan
if (isset($_POST['hapus'])) {
    $janjitemu_id = $_POST['janjitemu_id'];
    $deleteQuery = "DELETE FROM janji_temu WHERE janjitemu_id = :janjitemu_id AND user_id = :user_id";
    $stmtDelete = $pdo->prepare($deleteQuery);
    $stmtDelete->bindParam(':janjitemu_id', $janjitemu_id);
    $stmtDelete->bindParam(':user_id', $user_id);
    $stmtDelete->execute();
}

// Query untuk mendapatkan data riwayat janji temu
$queryRiwayat = "SELECT jt.janjitemu_id, l.nama_service, jt.tanggal_waktu, jt.status 
                 FROM janji_temu jt
                 JOIN layanan l ON jt.service_id = l.service_id
                 WHERE jt.user_id = :user_id
                 ORDER BY jt.tanggal_waktu DESC"; // Menampilkan berdasarkan tanggal terbaru

$stmtRiwayat = $pdo->prepare($queryRiwayat);
$stmtRiwayat->bindParam(':user_id', $user_id);
$stmtRiwayat->execute();
$riwayatData = $stmtRiwayat->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Janji Temu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        .status {
            font-weight: bold;
        }
        .hapus-btn {
            color: red;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h2>Riwayat Janji Temu Layanan</h2>

    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Layanan</th>
                <th>Tanggal dan Waktu</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($riwayatData) > 0): ?>
                <?php foreach ($riwayatData as $index => $riwayat): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td><?php echo htmlspecialchars($riwayat['nama_service']); ?></td>
                        <td><?php echo htmlspecialchars($riwayat['tanggal_waktu']); ?></td>
                        <td class="status"><?php echo htmlspecialchars($riwayat['status']); ?></td>
                        <td>
                            <!-- Form untuk hapus data -->
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="janjitemu_id" value="<?php echo $riwayat['janjitemu_id']; ?>">
                                <button type="submit" name="hapus" class="hapus-btn" onclick="return confirm('Apakah Anda yakin ingin menghapus janji temu ini?');">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">Belum ada riwayat janji temu.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <br>
    <nav>
        <a href="janjitemu_pengguna.php">Buat Janji Temu Baru</a>
    </nav>
</body>
</html>
