<?php
// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_bengkel";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Menambah data inventaris
if (isset($_POST['add_inventaris'])) {
    $nama_barang = $_POST['nama_barang'];
    $jumlah = $_POST['jumlah'];
    $tanggal_masuk = $_POST['tanggal_masuk'];
    $harga = $_POST['harga'];

    $add_sql = "INSERT INTO investaris (nama_barang, jumlah, tanggal_masuk, harga) VALUES ('$nama_barang', '$jumlah', '$tanggal_masuk', '$harga')";
    $conn->query($add_sql);
}

// Mengedit data inventaris
if (isset($_POST['update_inventaris'])) {
    $inventaris_id = $_POST['inventaris_id'];
    $nama_barang = $_POST['nama_barang'];
    $jumlah = $_POST['jumlah'];
    $tanggal_masuk = $_POST['tanggal_masuk'];
    $harga = $_POST['harga'];

    $update_sql = "UPDATE investaris SET nama_barang='$nama_barang', jumlah='$jumlah', tanggal_masuk='$tanggal_masuk', harga='$harga' WHERE inventaris_id='$inventaris_id'";
    $conn->query($update_sql);
}

// Menghapus data inventaris
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_sql = "DELETE FROM investaris WHERE inventaris_id='$delete_id'";
    $conn->query($delete_sql);
}

// Memeriksa apakah ada input pencarian
$search = "";
if (isset($_POST['search'])) {
    $search = $conn->real_escape_string($_POST['search']);
}

// Mengambil data inventaris
$sql = "SELECT * FROM investaris WHERE nama_barang LIKE '%$search%'";
$result = $conn->query($sql);

// Mengambil data laporan berdasarkan rentang tanggal
$startDate = $endDate = "";
$reportResult = [];
if (isset($_POST['generate_report'])) {
    $startDate = $_POST['start_date'];
    $endDate = $_POST['end_date'];
    $reportSql = "SELECT * FROM investaris WHERE tanggal_masuk BETWEEN '$startDate' AND '$endDate'";
    $reportResult = $conn->query($reportSql);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Inventaris</title>
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <style>
        /* Style untuk tabel */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    font-size: 16px;
    text-align: left;
}
table th, table td {
    border: 1px solid #ddd;
    padding: 12px 15px;
}
table th {
    background-color: #f4f4f4;
    color: #333;
    text-transform: uppercase;
}
table tr:nth-child(even) {
    background-color: #f9f9f9;
}
table tr:hover {
    background-color: #f1f1f1;
}

table td a {
    color: #007bff;
    text-decoration: none;
    margin-right: 10px;
}

table td a:hover {
    text-decoration: underline;
}

/* Style untuk form */
.form-container, .search-container, .report-container {
    background: #f4f4f4;
    padding: 20px;
    margin: 20px 0;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

form input[type="text"],
form input[type="number"],
form input[type="date"],
form input[type="submit"] {
    display: block;
    width: 100%;
    margin-bottom: 15px;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

form input[type="submit"] {
    background: #007bff;
    color: #fff;
    border: none;
    cursor: pointer;
    text-transform: uppercase;
}

form input[type="submit"]:hover {
    background: #0056b3;
}

/* Form pencarian */
.search-container input[type="text"] {
    width: calc(100% - 100px);
    display: inline-block;
    margin-right: 10px;
}

.search-container input[type="submit"] {
    width: auto;
    padding: 10px 20px;
}

/* Laporan container */
.report-container label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}
.report-container input[type="date"] {
    display: inline-block;
    width: calc(50% - 10px);
    margin-right: 10px;
}

    </style>
   <!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-smile'></i>
			<span class="text">Admin</span>
		</a>
		<ul class="side-menu top">
        <li>
				<a href="dashboard.php">
					<i class='bx bxs-shopping-bag-alt'></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="manajemen_pengguna.php">
					<i class='bx bxs-shopping-bag-alt'></i>
					<span class="text">Manajemen Pengguna</span>
				</a>
			</li>
			<li>
				<a href="manajemen_kampanye.php">
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">Manajemen Kampanye</span>
				</a>
			</li>
			<li>
				<a href="inventaris.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Investaris</span>
				</a>
			</li>
			<li>
				<a href="janjitemu_admin.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Janji Temu</span>
				</a>
			</li>
			<li>
				<a href="layanan_admin.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Layanan</span>
				</a>
			</li>
			<li>
				<a href="laporan.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Laporan Kinerja</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="settings.php">
					<i class='bx bxs-cog' ></i>
					<span class="text">Settings</span>
				</a>
			</li>
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="logout.php">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->

    <!-- CONTENT -->
    <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="notifikasi.php" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a>
        </nav>

        <main>
            <h2>Daftar Inventaris</h2>
            <!-- Form Pencarian -->
            <div class="search-container">
                <form method="POST" action="">
                    <input type="text" name="search" placeholder="Cari nama barang..." value="<?= htmlspecialchars($search); ?>">
                    <input type="submit" value="Cari">
                </form>
            </div>

            <!-- Form Tambah Inventaris -->
            <div class="form-container">
                <h3>Tambah Inventaris</h3>
                <form method="POST" action="">
                    <input type="text" name="nama_barang" placeholder="Nama Barang" required>
                    <input type="number" name="jumlah" placeholder="Jumlah Barang" required>
                    <input type="date" name="tanggal_masuk" required>
                    <input type="number" name="harga" placeholder="Harga" required>
                    <input type="submit" name="add_inventaris" value="Tambah">
                </form>
            </div>           

            <table>
                <tr>
                    <th>ID Inventaris</th>
                    <th>Nama Barang</th>
                    <th>Jumlah Barang</th>
                    <th>Tanggal Masuk</th>
                    <th>Harga</th>
                    <th>Aksi</th>
                </tr>
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['inventaris_id']; ?></td>
                        <td><?= $row['nama_barang']; ?></td>
                        <td><?= $row['jumlah']; ?></td>
                        <td><?= date('Y-m-d', strtotime($row['tanggal_masuk'])); ?></td>
                        <td><?= number_format($row['harga'], 2, ',', '.'); ?></td>
                        <td>
                            <a href="?edit_id=<?= $row['inventaris_id']; ?>">Edit</a> |
                            <a href="?delete_id=<?= $row['inventaris_id']; ?>" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6">Tidak ada data inventaris.</td></tr>
                <?php endif; ?>
            </table>

            <!-- Form Update Inventaris -->
            <?php if (isset($_GET['edit_id'])): 
                $edit_id = $_GET['edit_id'];
                $edit_sql = "SELECT * FROM investaris WHERE inventaris_id = '$edit_id'";
                $edit_result = $conn->query($edit_sql);
                $edit_row = $edit_result->fetch_assoc();
            ?>
            <div class="form-container">
                <h3>Update Inventaris</h3>
                <form method="POST" action="">
                    <input type="hidden" name="inventaris_id" value="<?= $edit_row['inventaris_id']; ?>">
                    <input type="text" name="nama_barang" value="<?= $edit_row['nama_barang']; ?>" required>
                    <input type="number" name="jumlah" value="<?= $edit_row['jumlah']; ?>" required>
                    <input type="date" name="tanggal_masuk" value="<?= $edit_row['tanggal_masuk']; ?>" required>
                    <input type="number" name="harga" value="<?= $edit_row['harga']; ?>" required>
                    <input type="submit" name="update_inventaris" value="Update">
                </form>
            </div>
            <?php endif; ?>

            <!-- Form Laporan -->
            <h2>Laporan Inventaris</h2>
            <div class="report-container">
                <form method="POST" action="">
                    <label for="start_date">Tanggal Mulai:</label>
                    <input type="date" name="start_date" required>
                    
                    <label for="end_date">Tanggal Akhir:</label>
                    <input type="date" name="end_date" required>
                    
                    <input type="submit" name="generate_report" value="Generate Report">
                </form>
            </div>

            <!-- Tampilkan Laporan -->
            <?php if (!empty($reportResult)): ?>
                <h3>Laporan Inventaris dari <?= $startDate; ?> sampai <?= $endDate; ?></h3>
                <table>
                    <tr>
                        <th>ID Inventaris</th>
                        <th>Nama Barang</th>
                        <th>Jumlah Barang</th>
                        <th>Tanggal Masuk</th>
                        <th>Harga</th>
                    </tr>
                    <?php if ($reportResult->num_rows > 0): ?>
                        <?php while($row = $reportResult->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['inventaris_id']; ?></td>
                            <td><?= $row['nama_barang']; ?></td>
                            <td><?= $row['jumlah']; ?></td>
                            <td><?= date('Y-m-d', strtotime($row['tanggal_masuk'])); ?></td>
                            <td><?= number_format($row['harga'], 2, ',', '.'); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5">Tidak ada data untuk rentang tanggal ini.</td></tr>
                    <?php endif; ?>
                </table>
            <?php endif; ?>

        </main>
    </section>
    <!-- CONTENT -->
</body>
</html>

<?php
$conn->close();
?>

