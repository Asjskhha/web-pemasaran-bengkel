<?php
// Menghubungkan ke database
include 'koneksi.php';  // Pastikan jalur ini sesuai dengan lokasi file koneksi Anda

// Pastikan ID pemesanan diterima di URL
if (isset($_GET['id'])) {
    $janjitemu_id = $_GET['id'];

    // Query untuk mengambil detail pemesanan berdasarkan id
    $queryDetail = "SELECT jt.janjitemu_id, jt.tanggal_waktu, jt.status, jt.catatan, l.nama_service, u.username 
                    FROM janji_temu jt
                    JOIN layanan l ON jt.service_id = l.service_id
                    JOIN users u ON jt.user_id = u.user_id
                    WHERE jt.janjitemu_id = :janjitemu_id";
    $stmtDetail = $pdo->prepare($queryDetail);
    $stmtDetail->bindParam(':janjitemu_id', $janjitemu_id);
    $stmtDetail->execute();
    $detailPemesanan = $stmtDetail->fetch(PDO::FETCH_ASSOC);

    // Jika data tidak ditemukan
    if (!$detailPemesanan) {
        echo "Detail pemesanan tidak ditemukan.";
        exit;
    }
} else {
    echo "ID pemesanan tidak ditemukan.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pemesanan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
        }
        .detail-container {
            width: 100%;
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        .detail-container h2 {
            margin-bottom: 20px;
        }
        .detail-container p {
            font-size: 18px;
        }
        .status {
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            color: white;
        }
        .status.Pending { background-color: yellow; }
        .status.Confirmed { background-color: green; }
        .status.Completed { background-color: blue; }
        .status.Cancelled { background-color: red; }
    </style>
</head>
<body>

    <h1>Detail Pemesanan</h1>
    <div class="detail-container">
        <h2>Pemesanan ID: <?php echo htmlspecialchars($detailPemesanan['janjitemu_id']); ?></h2>
        <p><strong>Nama Pengguna:</strong> <?php echo htmlspecialchars($detailPemesanan['username']); ?></p>
        <p><strong>Nama Layanan:</strong> <?php echo htmlspecialchars($detailPemesanan['nama_service']); ?></p>
        <p><strong>Tanggal Pemesanan:</strong> <?php echo htmlspecialchars($detailPemesanan['tanggal_waktu']); ?></p>
        <p><strong>Status:</strong> <span class="status <?php echo htmlspecialchars($detailPemesanan['status']); ?>">
            <?php echo htmlspecialchars($detailPemesanan['status']); ?></span>
        </p>
        <p><strong>Catatan:</strong> <?php echo htmlspecialchars($detailPemesanan['catatan']); ?></p>
        <a href="riwayat_janjitemu.php" class="button">Kembali ke Riwayat Pemesanan</a>
    </div>

</body>
</html>
