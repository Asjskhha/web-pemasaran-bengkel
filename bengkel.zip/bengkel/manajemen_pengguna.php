<?php
// Koneksi ke database
$host = 'localhost';
$dbname = 'db_bengkel';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi ke database gagal: " . $e->getMessage());
}

// Proses tambah pengguna
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $status = $_POST['status'];

    // Query untuk memasukkan data pengguna
    $sql = "INSERT INTO user (username, password, email, role, status) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);

    if ($stmt->execute([$username, $password, $email, $role, $status])) {
        echo "Pengguna berhasil ditambahkan.";
    } else {
        echo "Terjadi kesalahan saat menambah pengguna.";
    }
}

// Hapus pengguna
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Hapus data pengguna dari database
    $sql = "DELETE FROM user WHERE user_id = ?";
    $stmt = $pdo->prepare($sql);
    if ($stmt->execute([$delete_id])) {
        echo "Pengguna berhasil dihapus.";
    } else {
        echo "Terjadi kesalahan saat menghapus pengguna.";
    }
}

// Mendapatkan semua pengguna untuk Read
$sql = "SELECT * FROM user";
$stmt = $pdo->query($sql);
$users = $stmt->fetchAll();

// Mendapatkan data pengguna untuk Edit
$edit_user = null;
if (isset($_GET['edit_id'])) {
    $edit_id = $_GET['edit_id'];
    // Query untuk mendapatkan data berdasarkan user_id
    $sql = "SELECT * FROM users WHERE user_id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$edit_id]);
    $edit_user = $stmt->fetch();
}

// Proses edit pengguna
if (isset($_POST['update'])) {
    $edit_id = $_POST['user_id'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $status = $_POST['status'];

    // Query untuk update data pengguna
    $sql = "UPDATE user SET username = ?, password = ?, email = ?, role = ?, status = ? WHERE user_id = ?";
    $stmt = $pdo->prepare($sql);

    if ($stmt->execute([$username, $password, $email, $role, $status, $edit_id])) {
        echo "Pengguna berhasil diperbarui.";
    } else {
        echo "Terjadi kesalahan saat memperbarui pengguna.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Pengguna</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-smile'></i>
			<span class="text">Admin</span>
		</a>
		<ul class="side-menu top">
        <li>
				<a href="dashboard.php">
					<i class='bx bxs-shopping-bag-alt'></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="manajemen_pengguna.php">
					<i class='bx bxs-shopping-bag-alt'></i>
					<span class="text">Manajemen Pengguna</span>
				</a>
			</li>
			<li>
				<a href="manajemen_kampanye.php">
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">Manajemen Kampanye</span>
				</a>
			</li>
			<li>
				<a href="inventaris.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Investaris</span>
				</a>
			</li>
			<li>
				<a href="janjitemu_admin.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Janji Temu</span>
				</a>
			</li>
			<li>
				<a href="layanan_admin.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Layanan</span>
				</a>
			</li>
			<li>
				<a href="laporan.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Laporan Kinerja</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="settings.php">
					<i class='bx bxs-cog' ></i>
					<span class="text">Settings</span>
				</a>
			</li>
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="logout.php">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->

    <!-- CONTENT -->
        <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="notifikasi.php" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a>
        </nav>
        <div class="container mt-5">
            <h1>Daftar Pengguna</h1>
            <!-- Tombol untuk membuka modal tambah pengguna -->
            <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#tambahUserModal">Tambah Pengguna</button>

            <!-- Tabel Daftar Pengguna -->
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user_item): ?>
                        <tr>
                            <td><?= $user_item['username']; ?></td>
                            <td><?= $user_item['email']; ?></td>
                            <td><?= $user_item['role']; ?></td>
                            <td><?= $user_item['status']; ?></td>
                            <td>
                                <a href="?edit_id=<?= $user_item['user_id']; ?>" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editUserModal<?= $user_item['user_id']; ?>">Edit</a>
                                <a href="?delete_id=<?= $user_item['user_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus pengguna ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Modal untuk Form Tambah Pengguna -->
            <div class="modal fade" id="tambahUserModal" tabindex="-1" role="dialog" aria-labelledby="tambahUserModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="tambahUserModalLabel">Tambah Pengguna</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form method="POST" action="">
                                <div class="form-group">
                                    <label for="username">Username:</label>
                                    <input type="text" name="username" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password:</label>
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email:</label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="role">Role:</label>
                                    <select name="role" class="form-control" required>
                                        <option value="admin">Admin</option>
                                        <option value="user">User</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="status">Status:</label>
                                    <select name="status" class="form-control" required>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                                <button type="submit" name="submit" class="btn btn-success">Tambah Pengguna</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal untuk Form Edit Pengguna -->
            <?php foreach ($users as $user_item): ?>
            <div class="modal fade" id="editUserModal<?= $user_item['user_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editUserModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editUserModalLabel">Edit Pengguna</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form method="POST" action="">
                                <input type="hidden" name="user_id" value="<?= $user_item['user_id']; ?>">
                                <div class="form-group">
                                    <label for="username">Username:</label>
                                    <input type="text" name="username" value="<?= $user_item['username']; ?>" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password:</label>
                                    <input type="password" name="password" value="<?= $user_item['password']; ?>" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email:</label>
                                    <input type="email" name="email" value="<?= $user_item['email']; ?>" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="role">Role:</label>
                                    <select name="role" class="form-control" required>
                                        <option value="admin" <?= ($user_item['role'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
                                        <option value="user" <?= ($user_item['role'] == 'user') ? 'selected' : ''; ?>>User</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="status">Status:</label>
                                    <select name="status" class="form-control" required>
                                        <option value="active" <?= ($user_item['status'] == 'active') ? 'selected' : ''; ?>>Active</option>
                                        <option value="inactive" <?= ($user_item['status'] == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                                    </select>
                                </div>
                                <button type="submit" name="update" class="btn btn-warning">Update Pengguna</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <!-- CONTENT -->

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
