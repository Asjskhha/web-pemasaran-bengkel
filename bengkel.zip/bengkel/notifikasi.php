<?php
// Koneksi ke database
$conn = new mysqli("localhost", "username", "password", "db_bengke");

// Fungsi untuk menambahkan notifikasi baru
function tambahNotifikasi($user_id, $pesan) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO notifikasi (user_id, pesan, status, waktu_notifikasi) VALUES (?, ?, 'unread', NOW())");
    $stmt->bind_param("is", $user_id, $pesan);
    $stmt->execute();
    $stmt->close();
}

// Fungsi untuk mengambil notifikasi berdasarkan user_id
function getNotifikasi($user_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM notifikasi WHERE user_id = ? ORDER BY waktu_notifikasi DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $notifikasi = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $notifikasi;
}

// Fungsi untuk mengubah status notifikasi menjadi "read"
function updateStatusNotifikasi($notifikasi_id) {
    global $conn;
    $stmt = $conn->prepare("UPDATE notifikasi SET status = 'read' WHERE notifikasi_id = ?");
    $stmt->bind_param("i", $notifikasi_id);
    $stmt->execute();
    $stmt->close();
}

// Proses pengambilan dan penandaan notifikasi
if (isset($_GET['action'])) {
    if ($_GET['action'] == 'get') {
        $user_id = $_GET['user_id'];
        echo json_encode(getNotifikasi($user_id));
        exit;
    } elseif ($_GET['action'] == 'mark') {
        $notifikasi_id = $_GET['notifikasi_id'];
        updateStatusNotifikasi($notifikasi_id);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Notifikasi</title>
    <style>
        .notification { position: relative; display: inline-block; }
        #notification-icon { cursor: pointer; }
        #notification-list { display: none; position: absolute; top: 30px; right: 0; background: #f9f9f9; border: 1px solid #ddd; width: 250px; max-height: 200px; overflow-y: auto; }
        .notification-item { padding: 10px; border-bottom: 1px solid #ddd; cursor: pointer; font-weight: bold; }
        .notification-item.read { font-weight: normal; }
    </style>
</head>
<body>
    <!-- Notifikasi Icon dan List -->
    <div class="notification">
        <span id="notification-icon" onclick="toggleNotificationList()">🔔</span>
        <div id="notification-list">
            <!-- Notifikasi akan dimuat di sini -->
        </div>
    </div>

    <script>
    // Toggle tampilan daftar notifikasi
    function toggleNotificationList() {
        var list = document.getElementById("notification-list");
        list.style.display = list.style.display === "none" ? "block" : "none";
    }

    // Fungsi untuk memuat notifikasi
    function loadNotifications(userId) {
        fetch('?action=get&user_id=' + userId)
            .then(response => response.json())
            .then(data => {
                let notificationList = document.getElementById("notification-list");
                notificationList.innerHTML = "";
                data.forEach(notif => {
                    let item = document.createElement("div");
                    item.className = "notification-item " + (notif.status === 'read' ? 'read' : '');
                    item.innerHTML = notif.pesan + "<br><small>" + notif.waktu_notifikasi + "</small>";
                    item.onclick = function() {
                        markAsRead(notif.notifikasi_id);
                        item.classList.add("read"); // Tandai sebagai terbaca
                    };
                    notificationList.appendChild(item);
                });
            });
    }

    // Fungsi untuk menandai notifikasi sebagai terbaca
    function markAsRead(notifikasiId) {
        fetch('?action=mark&notifikasi_id=' + notifikasiId);
    }

    // Panggil fungsi loadNotifications dengan user_id dari session
    loadNotifications(<?php echo $_SESSION['user_id']; ?>);
    </script>
</body>
</html>
