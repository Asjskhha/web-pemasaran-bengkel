<?php
$host = 'localhost'; 
$db = 'db_bengkel'; 
$user = 'root'; 
$pass = '';

// Koneksi ke database
$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Tambah kampanye
if (isset($_POST['add_campaign'])) {
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tanggal_akhir = $_POST['tanggal_akhir'];
    $status = $_POST['status'];

    $sql = "INSERT INTO kampanye_pemasaran (judul, deskripsi, tanggal_mulai, tanggal_akhir, status)
            VALUES ('$judul', '$deskripsi', '$tanggal_mulai', '$tanggal_akhir', '$status')";

    if ($conn->query($sql) === TRUE) {
        header("Location: " . $_SERVER['PHP_SELF']);
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Edit kampanye
if (isset($_POST['edit_campaign'])) {
    $kampanye_id = $_POST['kampanye_id'];
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tanggal_akhir = $_POST['tanggal_akhir'];
    $status = $_POST['status'];

    $sql = "UPDATE kampanye_pemasaran SET 
            judul='$judul', 
            deskripsi='$deskripsi', 
            tanggal_mulai='$tanggal_mulai', 
            tanggal_akhir='$tanggal_akhir', 
            status='$status' 
            WHERE kampanye_id=$kampanye_id";

    if ($conn->query($sql) === TRUE) {
        header("Location: " . $_SERVER['PHP_SELF']);
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Hapus kampanye
if (isset($_GET['delete'])) {
    $kampanye_id = $_GET['delete'];
    $sql = "DELETE FROM kampanye_pemasaran WHERE kampanye_id=$kampanye_id";

    if ($conn->query($sql) === TRUE) {
        header("Location: " . $_SERVER['PHP_SELF']);
    } else {
        echo "Error: " . $conn->error;
    }
}

// Ambil data kampanye
$sql = "SELECT * FROM kampanye_pemasaran";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Kampanye</title>
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
    <!-- CSS Internal -->
    <style>
        /* Style untuk tabel */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    font-size: 16px;
    text-align: left;
}
table th, table td {
    border: 1px solid #ddd;
    padding: 12px 15px;
}
table th {
    background-color: #f4f4f4;
    color: #333;
    text-transform: uppercase;
}
table tr:nth-child(even) {
    background-color: #f9f9f9;
}
table tr:hover {
    background-color: #f1f1f1;
}

table td a {
    color: #007bff;
    text-decoration: none;
    margin-right: 10px;
}

table td a:hover {
    text-decoration: underline;
}

/* Style untuk form */
.form-container, .search-container, .report-container {
    background: #f4f4f4;
    padding: 20px;
    margin: 20px 0;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

form input[type="text"],
form input[type="number"],
form input[type="date"],
form input[type="submit"] {
    display: block;
    width: 100%;
    margin-bottom: 15px;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

form input[type="submit"] {
    background: #007bff;
    color: #fff;
    border: none;
    cursor: pointer;
    text-transform: uppercase;
}

form input[type="submit"]:hover {
    background: #0056b3;
}

/* Form pencarian */
.search-container input[type="text"] {
    width: calc(100% - 100px);
    display: inline-block;
    margin-right: 10px;
}

.search-container input[type="submit"] {
    width: auto;
    padding: 10px 20px;
}

/* Laporan container */
.report-container label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}
.report-container input[type="date"] {
    display: inline-block;
    width: calc(50% - 10px);
    margin-right: 10px;
}

    </style>
</head>
<body>
   <!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<i class='bx bxs-smile'></i>
			<span class="text">Admin</span>
		</a>
		<ul class="side-menu top">
        <li>
				<a href="dashboard.php">
					<i class='bx bxs-shopping-bag-alt'></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
			<li>
				<a href="manajemen_pengguna.php">
					<i class='bx bxs-shopping-bag-alt'></i>
					<span class="text">Manajemen Pengguna</span>
				</a>
			</li>
			<li>
				<a href="manajemen_kampanye.php">
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">Manajemen Kampanye</span>
				</a>
			</li>
			<li>
				<a href="inventaris.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Investaris</span>
				</a>
			</li>
			<li>
				<a href="janjitemu_admin.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Janji Temu</span>
				</a>
			</li>
			<li>
				<a href="layanan_admin.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Layanan</span>
				</a>
			</li>
			<li>
				<a href="laporan.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Laporan Kinerja</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="settings.php">
					<i class='bx bxs-cog' ></i>
					<span class="text">Settings</span>
				</a>
			</li>
			<li>
				<a href="logout.php" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="logout.php">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->

    <!-- CONTENT -->
        <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="notifikasi.php" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num">8</span>
			</a>
        </nav>
        <main>
        <h1>Manajemen Kampanye</h1>
        <form method="POST">
            <h2>Tambah Kampanye</h2>
            <label>Judul Kampanye:</label>
            <input type="text" name="judul" required>
            <label>Deskripsi:</label>
            <textarea name="deskripsi" required></textarea>
            <label>Tanggal Mulai:</label>
            <input type="date" name="tanggal_mulai" required>
            <label>Tanggal Akhir:</label>
            <input type="date" name="tanggal_akhir" required>
            <label>Status:</label>
            <select name="status">
                <option value="Aktif">active</option>
                <option value="Selesai">inactivi</option>
            </select>
            <input type="submit" name="add_campaign" value="Tambah">
        </form>

        <h2>Daftar Kampanye</h2>
        <table>
            <tr>
                <th>ID Kampanye</th>
                <th>Judul</th>
                <th>Deskripsi</th>
                <th>Tanggal Mulai</th>
                <th>Tanggal Akhir</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['kampanye_id']; ?></td>
                <td><?php echo $row['judul']; ?></td>
                <td><?php echo $row['deskripsi']; ?></td>
                <td><?php echo $row['tanggal_mulai']; ?></td>
                <td><?php echo $row['tanggal_akhir']; ?></td>
                <td><?php echo $row['status']; ?></td>
                <td>
                    <a href="?delete=<?php echo $row['kampanye_id']; ?>" class="delete-btn">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
        </main>
    </section>
    <!-- CONTENT -->
</body>
</html>
