<?php
// Menghubungkan ke database
include 'koneksi.php';  // Pastikan jalur ini sesuai dengan lokasi file koneksi Anda

// Query untuk mengambil data layanan dari database
$queryLayanan = "SELECT service_id, nama_service, deskripsi_service, price, durasi, status FROM layanan WHERE status = 'Aktif'"; // Menampilkan hanya layanan yang aktif

$stmtLayanan = $pdo->prepare($queryLayanan);
$stmtLayanan->execute();
$layananData = $stmtLayanan->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Layanan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        .status {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h2>Daftar Layanan Tersedia</h2>

    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Layanan</th>
                <th>Deskripsi Layanan</th>
                <th>Harga</th>
                <th>Durasi</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($layananData) > 0): ?>
                <?php foreach ($layananData as $index => $layanan): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td><?php echo htmlspecialchars($layanan['nama_service']); ?></td>
                        <td><?php echo htmlspecialchars($layanan['deskripsi_service']); ?></td>
                        <td><?php echo 'Rp ' . number_format($layanan['price'], 0, ',', '.'); ?></td>
                        <td><?php echo htmlspecialchars($layanan['durasi']); ?></td>
                        <td class="status"><?php echo htmlspecialchars($layanan['status']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">Tidak ada layanan tersedia.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <br>
    
</body>
</html>
