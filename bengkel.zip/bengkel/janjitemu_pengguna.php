<?php
// Menghubungkan ke database
include 'koneksi.php';  // Pastikan jalur ini sesuai dengan lokasi file koneksi Anda

// Mendapatkan daftar layanan dari database
$queryLayanan = "SELECT * FROM layanan";
$stmtLayanan = $pdo->prepare($queryLayanan);
$stmtLayanan->execute();
$layananData = $stmtLayanan->fetchAll(PDO::FETCH_ASSOC);

// Jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = 1; // Gantilah dengan ID pengguna yang sesuai
    $service_id = $_POST['service_id'];
    $tanggal_waktu = $_POST['tanggal_waktu'];

    try {
        $query = "INSERT INTO janji_temu (user_id, service_id, tanggal_waktu, status) 
                  VALUES (:user_id, :service_id, :tanggal_waktu, 'Menunggu')";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':service_id', $service_id);
        $stmt->bindParam(':tanggal_waktu', $tanggal_waktu);
        $stmt->execute();

        echo "<p class='success'>Janji temu berhasil dibuat!</p>";
    } catch (PDOException $e) {
        echo "<p class='error'>Error: " . $e->getMessage() . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Buat Janji Temu</title>
    <style>
        /* Style untuk card */
        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 80%;
            max-width: 500px;
            margin: 20px auto;
        }

        .card h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .card form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .card label {
            font-size: 16px;
            font-weight: bold;
        }

        .card input[type="text"],
        .card input[type="datetime-local"],
        .card select,
        .card input[type="submit"] {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        .card input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: bold;
            text-transform: uppercase;
        }

        .card input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .card .success, .card .error {
            text-align: center;
            padding: 10px;
            margin-top: 15px;
            border-radius: 5px;
        }

        .card .success {
            background-color: #28a745;
            color: white;
        }

        .card .error {
            background-color: #dc3545;
            color: white;
        }
        
    </style>
</head>
<body>
    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <i class='bx bxs-smile'></i>
            <span class="text">User</span>
        </a>
        <ul class="side-menu top">
            <li>
                <a href="janjitemu_pengguna.php">
                    <i class='bx bxs-shopping-bag-alt'></i>
                    <span class="text">Janji Temu</span>
                </a>
            </li>
            <li>
                <a href="layanan_pengguna.php">
                    <i class='bx bxs-doughnut-chart'></i>
                    <span class="text">Layanan</span>
                </a>
            </li>
            <li>
                <a href="logout.php" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Logout</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->

    <!-- CONTENT -->
    <section id="content">
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <a href="notifikasi.php" class="notification">
                <i class='bx bxs-bell'></i>
                <span class="num">8</span>
            </a>
        </nav>

        <!-- Card untuk form buat janji temu -->
        <div class="card">
            <h2>Buat Janji Temu Layanan</h2>
            <!-- Form untuk buat janji temu -->
            <form action="janjitemu_pengguna.php" method="POST">
                <label for="service_id">Pilih Layanan:</label>
                <select name="service_id" id="service_id" required>
                    <option value="">--Pilih Layanan--</option>
                    <?php foreach ($layananData as $layanan): ?>
                        <option value="<?php echo $layanan['service_id']; ?>">
                            <?php echo htmlspecialchars($layanan['nama_service']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="tanggal_waktu">Pilih Tanggal dan Waktu:</label>
                <input type="datetime-local" id="tanggal_waktu" name="tanggal_waktu" required>

                <input type="submit" value="Buat Janji Temu">
            </form>

            <!-- Pesan berhasil atau gagal -->
            <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                if (isset($error)) {
                    echo "<div class='error'>{$error}</div>";
                } else {
                    echo "<div class='success'>Janji temu berhasil dibuat!</div>";
                }
            }
            ?>

        </div>
    </section>
</body>
</html>
