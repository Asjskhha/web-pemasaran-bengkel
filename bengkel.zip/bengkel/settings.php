<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Settings</title>
    <style>
        /* CSS styling untuk tata letak dan tampilan form */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .settings-container {
            width: 80%;
            max-width: 600px;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .settings-container h2 {
            text-align: center;
            color: #333;
        }
        .form-section {
            margin-bottom: 20px;
        }
        .form-section h3 {
            color: #555;
            margin-bottom: 10px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .submit-button {
            display: block;
            width: 100%;
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 12px;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        .submit-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="settings-container">
    <h2>Admin Settings</h2>
    
    <!-- Section Pembaruan Profil -->
    <div class="form-section">
        <h3>Update Profile</h3>
        <form id="profileForm">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" placeholder="Enter your username" required>
            
            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>
        </form>
    </div>

    <!-- Section Pembaruan Kata Sandi -->
    <div class="form-section">
        <h3>Change Password</h3>
        <form id="passwordForm">
            <label for="currentPassword">Current Password</label>
            <input type="password" id="currentPassword" name="currentPassword" placeholder="Enter current password" required>
            
            <label for="newPassword">New Password</label>
            <input type="password" id="newPassword" name="newPassword" placeholder="Enter new password" required>
            
            <label for="confirmPassword">Confirm New Password</label>
            <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm new password" required>
        </form>
    </div>

    <!-- Section Pengaturan Aplikasi Lainnya -->
    <div class="form-section">
        <h3>App Settings</h3>
        <form id="appSettingsForm">
            <label for="notifications">Enable Notifications</label>
            <select id="notifications" name="notifications">
                <option value="enabled">Enabled</option>
                <option value="disabled">Disabled</option>
            </select>
            
            <label for="timezone">Time Zone</label>
            <input type="text" id="timezone" name="timezone" placeholder="Enter your time zone" required>
        </form>
    </div>

    <!-- Button Submit -->
    <button class="submit-button" onclick="saveSettings()">Save Changes</button>
</div>

<script>
    // JavaScript sederhana untuk fungsi penyimpanan pengaturan
    function saveSettings() {
        alert("Settings have been saved!");
    }
</script>

</body>
</html>





